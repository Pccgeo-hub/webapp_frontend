import logo from './logo.svg';
import './App.css';

import Create from './component/Create';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      <form></form>
     
      <Create />
      </header>
     
    </div>
  );
}

export default App;
