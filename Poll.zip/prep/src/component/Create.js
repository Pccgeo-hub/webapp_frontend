import React from 'react'


function App() {
    const [polls, setpolls] = React.useState([])
    const [poll, setpoll] = React.useState("")
    const [pollEditing, setpollEditing] = React.useState(null)
    const[editingText, setEditingText] = React.useState("")


    const[form,setForm]= React.useState({
        name:'',
      });
    
      const onChange =(e)=>{
        const {value, name, type, checked } = e.target;
    
        setForm((state) => ({
          ...state,
          [name]: type === 'checkbox'? checked : value
        }));
      }
    
      const showData = () =>{
        console.log('Form: ', form);
      }
    
      const onSubmit = (e) =>{
        showData();
        e.preventDefault();
      }
    
   /* React.useEffect(() => {
      const temp = localstorage.getItem("polls")
      const loadedpolls = JSON.parse(temp)
      
      if(loadedpolls) {
        setpolls(loadedpolls)
      }
    }, [])

    React.useEffect(() => {
      const temp = JSON.stringify(polls)
      localStorage.setItem("polls", temp)
    }, [polls]) */

    function handleSubmit(e) {
      e.preventDefault()

      const newpoll = {
        id: new Date().getTime(),
        text: poll,
        completed: false,
      }
      setpolls([...polls].concat(newpoll))
      setpoll("")
    }

    function deletepoll(id) {
      const updatedpolls = [...polls].filter((poll) => poll.id !== id)

      setpolls(updatedpolls)
    }

    function toggleComplete(id) {
      const updatedpolls = [...polls].map((polls) => {
        if(poll.id === id){
          poll.completed = !poll.completed
        }
        return poll
      })
      setpolls(updatedpolls)
    }

    function editpoll(id) {
      const updatedpolls = [...polls].map((poll) => {
        if(poll.id === id) {
          poll.text = editingText
        }
        return poll
      })
      setpolls(updatedpolls)
      setpollEditing(null)
      setEditingText("")
    }
      
  return (
    <div className="App">
      <h1>Create poll</h1>
      <form onSubmit={handleSubmit}>

          <label className="name">
            Poll Name:
            <input className="fname" onChange={onChange} name="name" value={form.name}/>
          </label>


           <br></br>
          <label>
              Questions:
          <input type="text" onChange={(e) => setpoll(e.target.value)} value={poll}/>
          </label>
          <br></br>

          <label className="name">
            Input Type:
            <div>
            <input onChange={onChange} type="radio" value="Text" name="input" />Text
            <input onChange={onChange} type="radio" value="Option" name="input" />option
            <input onChange={onChange} type="radio" value="File" name="input" />File
            </div>
            </label>

      
         

        
        <button type="submit">Add poll</button>
        
      </form>
      <form onSubmit={onSubmit}>

        <button className="submit">Submit</button>
      </form>
      {polls.map((poll) => <div key= {poll.id}>

        {pollEditing === poll.id ? 
        ( <input 
        type="text" 
        onChange={(e) => setEditingText(e.target.value)}
        value={editingText}
        />)
        : (<div>{poll.text}</div>)}
        
        <button className='st' onClick = {() => deletepoll(poll.id)}>Delete</button>
        <input className='check' type="checkbox" onChange={() => toggleComplete(poll.id)} 
         checked={poll.completed} />

         {pollEditing === poll.id ? 
         (<button onClick={() => editpoll(poll.id)} >Submit Edits</button>) :
          (<button onClick={() => setpollEditing(poll.id)} >Edit poll</button>)}

                
           
          
        
         
         
      </div>)}
    </div>

    
  );
}

export default App;