const quizData = [
    {
        question:'how old is Florin?',
        a: '10',
        b: '17',
        c: '26',
        d: '110',
        correct: 'c'
    }, {
        question: 'What is the most used programming language in 2019?',
        a: 'Java',
        b: 'c',
        c: 'Python',
        d: 'Javascript',
        correct: 'd'
    }, {
        question:'Who is the President of US?',
        a: 'Florin Pop',
        b: 'Donald Trump',
        c: 'Ivan Saldano',
        d: 'Mihai Andrei',
        correct: 'b'
    },  {
        question:'What does HTML stand for?',
        a: 'Hypertext Markup Languauge',
        b: 'Cascading Style sheet',
        c: 'Jason Object Notation',
        d: 'Helicopters Terminal Motorboats Lamborginis',
        correct: 'a'
    },  {
        question:'What year was Javascript Launched?',
        a: '1996',
        b: '1995',
        c: '1994',
        d: 'none of the above',
        correct: 'd'
    },
]